import csv
import uuid


#prescripts
platform_ios = {
    "os":'ios',
    "package_name": 'com.neise.tvr',
    "app_name": 'ppt.ios',
    "device_modal": 'iPhone'
}

# platform_android= {
#     "os": 'Android',
#     "package_name": 'com.pstation.pili',
#     "app_name": 'ppt',
#     "device_modal": 'Xiaomi'
# }
labels = ['device_uniq','os','package_name','app_name','device_modal']
#write csv
try:
    with open("/Users/nina/Desktop/pilipili_jmeter/test1w.csv","w+") as f:
        writer = csv.DictWriter(f,fieldnames=labels)
        writer.writeheader()
        for i in range(0, 100000):
            list=[]
            device_uniq = uuid.uuid4()
            platform_ios["device_uniq"]=device_uniq
            list.append(platform_ios)
            writer.writerow(list[0])
except IOError:
    print("I/O error")
print("循环次数>>>>>"+str(i+1))
#read csv
# try:
#     with open("/Users/nina/Desktop/pilipili_jmeter/test1w.csv","r") as f:
#         reader = csv.reader(f)
#         for line in reader:
#             print(line)
# except IOError:
#     print("I/O error")